include <sound.h>


if(DSP_READ == true){
DSP_OUTPUT_RATE(const int); 
DMA_COUNT(const char);
DMA_ADDRES(const char,char 'A'); 
};
if(DSP_READ == false){
reset_DSP();
}

// bir taşlan  dört kuş açıklamada yazıyor
// with one stone four bird writing in info

