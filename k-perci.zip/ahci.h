typedef enum
{
FIS_TYPE_REG_H2D  = 0x27,
FIS_TYPE_REG_D2H  = 0x34,
FIS_TYPE_DMA_ACT  = 0x39,
FIS_TYPE_DMA_SETUP = 0x41,
FIS_TYPE_DATA     = 0x46,
FIS_TYPE_BIST     = 0x58,
FIS_TYPE_PIO_SETUP = 0x5F,
FIS_TYPE_DEV_BITS  = 0xA1,
}FIS_TYPE;

typedef struct tag FIS_REG_H2D
{
  uint8_t fistype;
  
  uint8_t pmport:4;
  uint8_t rsv0:3;
  uint8_t c:1;
  
  uint8_t command;
  uint8_t featurel;
  
  uint8_t lba0;
  uint8_t lba1;
  uint8_t lba2;
  uint8_t device;
  
  uint8_t lba3;
  uint8_t lba4;
  uint8_t lba5;
  uint8_t featureh;
  
  uint8_t countl;
  uint8_t counth;
  uint8_t icc;
  uint8_t control;
  
  uint8_t rsv1[4]
  } FIS_REG_H2D;
  
  typedef struct tag FIS_REG_D2H
{
  uint8_t fistype;
  
  uint8_t pmport:4;
  uint8_t rsv0:2;
  uint8_t i:1;
  uint8_t rsv1:1;
  
  uint8_t status;
  uint8_t erroe;
  
  uint8_t lba0;
  uint8_t lba1;
  uint8_t lba2;
  uint8_t device;
  
  uint8_t lba3;
  uint8_t lba4;
  uint8_t lba5;
  uint8_t rsv2;
  
  uint8_t countl;
  uint8_t counth;
  uint8_t rsv3[2];

  
  uint8_t rsv4[4]
  } FIS_REG_D2H;
  
 typedef struct tag FIS_DATA
  {
  uint8_t fistype;
  
  uint8_t pmport:4;
  uint8_t rsv0:4;
  
  uint8_t rsv1[2];
  
  uint32_t data[1];
  }FIS_DATA
  
  typedef struct tag FIS_PIO_STP
{
  uint8_t fistype;
  
  uint8_t pmport:4;
  uint8_t rsv0:3;
  uint8_t d:1;
  uint8_t i:1;
  uint8_t rsv1:1;
  
  uint8_t status;
  uint8_t error;
  
  uint8_t lba0;
  uint8_t lba1;
  uint8_t lba2;
  uint8_t device;
  
  uint8_t lba3;
  uint8_t lba4;
  uint8_t lba5;
  uint8_t rsv2;
  
  uint8_t countl;
  uint8_t counth;
  uint8_t rsv3;
  uint8_t e_status;
  
  uint16_tc;
  uint8_t rsv4[2];
  } FIS_PIO_STP;
  
  typedef struct tag FIS_DMA_STP
{
  uint8_t fistype;
  
  uint8_t pmport:4;
  uint8_t rsv0:3;
  uint8_t d:1;
  uint8_t i;
  uint8_t a;
  
  uint8_t rsved[2];
  
  uint8_t DMAbuffID;
  
  uint8_t rsvd;
  
  uint8_t DMAbuffOS;
  
  uint8_t TransferCount;
  
  uint8_t resvd;
  
  } FIS_DMA_STP;
  
  typedef volatile struct tag HBA_MEM
{
  uint8_t cap;
  uint8_t ghc;
  uint8_t is;
  uint8_t pi;
  uint8_t vs;
  uint8_t ccc_ctl;
  uint8_t ccc_pts;
  uint8_t en_loc;
  uint8_t en_ctl;
  uint8_t cap2;
  uint8_t bohc;
  
  uint8_t rsv[0xA0-0x2C];
  
  uint8_t vendor[0x100-0xA0];
  
  HBA_PORT ports[1];
  } HBA_MEM;
  
  typedef volatile struct tag FIS_REG_H2D
{
  uint8_t clb;
  uint8_t clbu;
  uint8_t fb;
  uint8_t fbu;
  uint8_t is;
  uint8_t ie;
  uint8_t cmd;
  uint8_t rsv0;
  uint8_t tfd;
  uint8_t sig;
  uint8_t ssts;
  uint8_t sctl;
  uint8_t serr;
  uint8_t sact;
  uint8_t ci;
  uint8_t sntf;
  uint8_t fbs;
  uint8_t rsf1[11];
  uint8_t vendor[4]
  } FIS_REG_H2D;
  typedef volatile struct tagHBA_FIS { 	
  	FIS_DMA_SETUP	dsfis;	
  	uint8_t pad0[4]; 
  	FIS_PIO_SETUP	psfis;	
  	uint8_t pad1[12];  
   FIS_REG_D2H	rfis;	
  	uint8_t pad2[4];   
  FIS_DEV_BITS	 sdbfis; 	uint8_t ufis[64]; 
 	uint8_t 	rsv[0x100-0xA0]; }
 	 HBA_FIS;
 	 
 	  typedef struct tag HBA_CMD_HEADER
{
  
  uint8_t cfl:5;
  uint8_t a:1;
  uint8_t w:1;
  uint8_t p:1;

  uint8_t r:1;
  uint8_t b:1;
  uint8_t c:1;
  uint8_t rsv0:1;
  uint8_t pmp:4;
  
  uint16_t prdtl;
  
  volatile
  uint32_t prdbc;
  
  uint32_t ctba;
  uint32_t ctbau;
  
  uint8_t rsv4[2];
  } HBA_CMD_HEADER;
  
 	 	 
 	  typedef struct tag HBA_CMD_TBL
{
  
  uint8_t cfis[64];
  
  uint8_t acmd[16];
  
  uint8_t rsv[48];
  
  HBA_PRDT_ENTRY prdt_entry[1];
  } HBA_CMD_TBL
 typedef struct tag HBA_PRDT_ENTRY
{
  
  uint32_t dba;
  uint32_t dbau;
  uint32_t rsv0;
  
  uint32_t dbc:22;
  uint32_t rsv1:9;
  uint32_t i:1;
  
  } HBA_PRDT_ENTRY

