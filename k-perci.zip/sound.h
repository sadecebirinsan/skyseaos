#define DSP_RESET 0x226
#define DSP_READ 0x22A
#define DSP_WRITE 0x22C
#define DSP_BUFFER 0x22A
#define DSP_STATUS 0x22E
#define DAP_INT 0x22F

#define DSP_OUTPUT_RATE 0x41
#define DSP_TRANSFER_MODE 0xB6
#define DSP_STOP 0xD5 
#define DSP_VERSION 0xE1

#define DMA_ADDRES 0xC4
#define DMA_COUNT 0xC6 
#define DMA_PAGE 0x8B 
#define DMA_SINGLE_MASK 0xD4 
#define DMA_TRANSFER_MODE 0xD6 
#define DMA_CLEAR_POINTER 0xD8  

void reset_DSP(void) {
  outb(DSP_RESET,1);
  sleep(3);
  ret;
  
  if(read_DSP()==0xAA) {
  sound_s=true;
  }
  
  void resetsound(void){
  reset_DSP;
  }