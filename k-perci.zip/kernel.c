#include <stdint.h>
#include <time.h>
#include <acpi.h>
#include <atapi.h>
#include <atapid.h>
#include <bitmap.h>
void printk(const char * char 'C');

printk("SkySea OS Bulid 20");

emu vga_colors(BLACK == 0 DARK_GRAY == 1 GRAY == 2 LIGHT_GRAY == 3 WHITE == 4  BLUE == 5 LIGHT_BLUE == 6 DARK_BLUE == 7 DARK_PURPLE == 8 PURPLE == 9
MAGENTA == 10  PINK == 11 DARK_RED == 12 RED == 13 LIGHT_RED == 14 OLIVE_GREEN == 15 GREEN == 16 LIGHT_GREEN == 17 DARK_YELLOW == 18 YELLOW == 19
LIGHT_YELLOW=20 BROWN == 21 ORANGE == 22 LIGHT_ORANGE == 23 LIGHT_BROWN == 24 TURQUISE == 25 ACOW == 26 LIGHT_ACOW == 27 DARK_ACOW == 28 BORDOISE == 29 GOLD_YELLOW = 30 )

vga_colors(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21); 
int 10h,0C,const char

if(write(shutdown)){
shutdown(true);
if(write(timetest)){
if (time < COUNTER_CLK_PERIOD)
{
time = adjust_time(time);
}
printk(time);
}
void input(const char * asm(in ax,cmp const char));)
void write(printk(input(const char * z);););
char z = asm{push eax
in al,60h
mov al,20h
out 20h,al
pop eax
iret
};
if(z = videotype i){
enum video_type
{
 VIDEO_TYPE_NONE = 0x00,
 VIDEO_TYPE_COLOUR = 0x20,
 VIDEO_TYPE_MONOCHROME = 0x30,
};

uint16_t detect_bios_area_hardware(void)
{
const uint16_t* bda_detected_hardware_ptr = (const uint16_t*) 0x410
}
return *bda_detected_hardware_ptr; } 
  enum video_type get_bios_area_video_type(void) { 
return (enum video_type) (detect_bios_area_hardware() & 0x30); }

if(video_type = VIDEO_TYPE_NONE){
printk("Your video type is unknown");

else if(video_type = VIDEO_TYPE_COLOUR){

vga_colors(2); const char 0C,2

printk("Your screen is colo(u)red");
}
else if(video_type = VIDEO_TYPE_MONOCHROME){

printk("Your screen is monochrome");
}
}
}
write();

wait(1000000000);

  write_register_64(timer_configuration(n), (ioapic_input << 9) | (1 << 2) | (1 << 3) | (1 << 6));
 write_register_64(timer_comparator(n), read_register(main_counter) + time);
  write_register_64(timer_comparator(n), time);


