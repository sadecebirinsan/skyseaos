struct VbeInfoBlock {
 char VbeSignature[4]
 uint16_t VbeVersion;
 int16_t OemStringPtr[2];
  uint8_t Capabilities[4];
   uint16_t VideoModePtr[2]; 
    uint16_t TotalMemory; } 
    __attribute__((packed));
VbeInfoBlock *vib = dos_alloc(512); 
v86_bios(0x10, {ax:0x4f00, es:SEG(vib), di:OFF(vib)}, &out); 
if (out.ax!=0x004f) fatalite("Graphic info is un readable or getted with mistakes.");
struct ModeInfoBlock {
uint16_t attribute;
uint8_t winA,winB;
uint16_t granularity;
uint16_t winsize;
uint16_t segmentA, segmentB;
VBE_FAR(realFctPtr);
uint16_t pitch;

uint16_t Xres, Yres;
uint8_t Wchar, Ychar, planes, bpp, banks;
uint8_t memory_model, bank_size, image_pages;
uint8_t reserved0;

uint8_t red_mask, red_position;
uint8_t green_mask,green_position;
uint8_t blue_mask,blue_position;
uint8_t rsv_mask, rsv_position;
uint8_t directcolor_attributes;

uint32_t physbase;
uint32_t reserved1;
uint16_t reserved2;
}__attribute__((packed));

uint16_t findMode(int x, int y, int d) 
{ struct VbeInfoBlock *ctrl = (VbeInfoBlock *)0x2000;
 struct ModeInfoBlock *inf = (ModeInfoBlock *)0x3000;
 uint16_t *modes; 
int i;
 uint16_t best = 0x13;
 int pixdiff, bestpixdiff = DIFF(320 * 200, x * y);
 int depthdiff, bestdepthdiff = 8 >= d ? 8 - d : (d - 8) * 2; 
  strncpy(ctrl->VbeSignature, "VBE2", 4);
 intV86(0x10, "ax,es:di", 0x4F00, 0, ctrl);  
 if ( (uint16_t)v86.tss.eax != 0x004F ) return best;  
 modes = (uint16_t*)REALPTR(ctrl->VideoModePtr); 
for ( i = 0 ; modes[i] != 0xFFFF ; ++i )
 { intV86(0x10, "ax,cx,es:di", 0x4F01, modes[i], 0, inf); 
  if ( (uint16_t)v86.tss.eax != 0x004F ) continue; 
 if ( (inf->attributes & 0x90) != 0x90 ) continue; 
 if ( inf->memory_model != 4 && inf->memory_model != 6 ) 
 continue; 
 for if ( x == inf->XResolution && y == inf->YResolution && d == inf->BitsPerPixel ) return modes[i];  
 pixdiff = DIFF(inf->Xres * inf->Yres, x * y);
  depthdiff = (inf->bpp >= d)? inf->bpp - d : (d - inf->bpp) * 2; 
  if ( bestpixdiff > pixdiff || (bestpixdiff == pixdiff && bestdepthdiff > depthdiff) )
   { best = modes[i]; bestpixdiff = pixdiff; bestdepthdiff = depthdiff; } } 
   if ( x == 640 && y == 480 && d == 1 ) return 0x11; 
   return best; 