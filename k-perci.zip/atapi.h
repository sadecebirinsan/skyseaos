uint8_t atapi_readtoc[]= { 0x43, 0, 1, 0, 0, 0, 0, 0, 12, 0x40, 0, 0};
outb (0x1F6, slavebit<<4);
outb (0x1F1, isDMA);
outb (0x1F4, (maxByteCount & 0xff));
outb (0x1F4, (maxByteCount >> 8));
outb (0x1F7, 0xA0);
outw (0x1F0, Command1);
outw (0x1F0, Command2);
outw (0x1F0, Command3);
outw (0x1F0, Command4);
outw (0x1F0, Command5);
outw (0x1F0, Command6);
wordcount = bytecount/2;

void idpaging ( uint32_t * first_pte , vaddr from , int size) {
from = from & 0xfffff000 ;
for(; size>0 from += 4096, size -= 4096, first_pte++){
*first_pte = from | 1;
}
}



if(0x00 = true){

idpaging(0x03);
if(0x03 = 1){


else{
wrstr("CD driver not founded");
}

0x1B = 1

0x25, uint_32(byte) * const char,const int

