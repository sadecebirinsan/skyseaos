#include <fs.c>
#include <mm.c>
char read;
char write;
char[activity]={write,read};

volatile void read(char[activity)={read};){
malloc(poolpaged);
manmem(00x0050);
int[binary]={0,1};
char[codes]={malloc(codes.los);};
char[text]={malloc(text.los);};
char[symbol]={malloc(sym.los);};
float[numbers]={malloc(math.los);};
}

volatile void write(char[activity)={write};){
malloc(poolunpaged);
manmem(00x0060);
manmem{
int[binary]={0,1};
char[codes]={malloc(codes.los);};
char[text]={malloc(text.los);};
char[symbol]={malloc(symbol.los);};
float[numbers]={malloc(math.los);};
}
}