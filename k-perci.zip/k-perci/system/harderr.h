
include <asm/asm.s>

void(coprosseccorerror);
void(pageerror);
void(asmdiv);
void(protect);
static void kill(char * str,long esp_str,long nr){
long * esp = (long *) esp_ptr;
int z;
}

if(coprosseccorerror){
kill();
}
if(pageerror){
kill();
}
if(asm(div 0);){
kill();
)

if(rev = true){
kill();
}

if(coprosseccorerror && pageerror && int){
kill(int 13);
}
