#define SATA_SIG_ATA 0x00000101
#define SATA_SIG_ATAPI 0xEB140101
#define SATA_SIG_SEMB 0xC33C0101
#define SATA_SIG_PM 0x00000101
#define AHCI_BASE 0x400000
#define HBA_PxCMD_ST 0x0001 
#define HBA_PxCMD_FRE 0x0010 
#define HBA_PxCMD_FR 0x4000 
#define HBA_PxCMD_CR 0x8000  
#define AHCI_DEV_NULL 0
#define AHCI_DEV_SATA 1
#define AHCI_DEV_SEMB 2
#define AHCI_DEV_PM 3
#define AHCI_DEV_SATAPI 4

#define HBA_PORT_IPM_ACTIVE 1
#define HBA_PORT_DET_PRESENT 3

void probe_port(HBA_MEM *abar)
{
    uint32_t pi = abar->pi;
    int i = 0;
    while(i<31)
    {
     if (pi & 1)
     {
          int dt = check_type(&abar->pprts[i]);
          if (dt == AHCI_DEV_SATA)
          {
           printk("SATA driver is founded\n", i);
           }
          else if (dt == AHCI_DEV_SATAPI)
          {
          printk("SATAPI surucusu bulunmustur", i);
          }
          else if (dt == AHCI_DEV_SEMB)
          {
           printk("SEMB surucusu bulunmustur", i);
           }
          else if (dt == AHCI_DEV_SATAPI)
          {
          printk("PM surucusu bulunmustur", i);
          }
          else
          { 
          printk("Surucu bulunamadi", i);
           }
   }
   
   }
static int check_type(HBA_PORT *port)
{
 uint32_t ssts = port->ssts;
  uint8_t ipm = (ssts >> 8) & 0x0F; 
	uint8_t det = ssts & 0x0F;     
	
	if (det != HBA_PORT_DET_PRESENT)
	           return AHCI_DEV_NULL;
	 if (det != HBA_PORT_DET_ACTIVE)
	           return AHCI_DEV_NULL;
	 switch (port->sig)
	 case SATA_SIG_ATAPI: 	
	 	return AHCI_DEV_SATAPI; 
	 		case SATA_SIG_SEMB: 	
	 			return AHCI_DEV_SEMB; 
	 			case SATA_SIG_PM: 		
	 			return AHCI_DEV_PM; 
	 				default: 		
	 				return AHCI_DEV_SATA; 
	 					} 
	 					}
void port_rebase(HBA_PORT *port, int portno)
{
      stop_cmd(port);
      
port->clb = AHCI_BASE + (portno<<10);
port->clbu = 0; 	
memset((void*)(port->clb), 0, 1024);  
port->fb = AHCI_BASE + (32<<10) + (portno<<8); 	
port->fbu = 0; 	
memset((void*)(port->fb), 0, 256);  
HBA_CMD_HEADER *cmdheader = (HBA_CMD_HEADER*)(port->clb); 	
for (int i=0; i<32; i++) 	{ 		
cmdheader[i].prdtl = 8;
cmdheader[i].ctba = AHCI_BASE + (40<<10) + (portno<<13) + (i<<8); 	
cmdheader[i].ctbau = 0; 	
memset((void*)cmdheader[i].ctba, 0, 256);
		}   	
	start_cmd(port);
	 void start_cmd(HBA_PORT *port)
	  { 

	 while (port->cmd & HBA_PxCMD_CR);  
	 port->cmd |= HBA_PxCMD_FRE; 
	 port->cmd |= HBA_PxCMD_ST; 
	 	}
	 	  void stop_cmd(HBA_PORT *port)
	 	  { 	
	 	  
	 	  while(1) 	
	 	  { 		if (port->cmd & HBA_PxCMD_FR) 			
	 	  continue; 		
	 	  if (port->cmd & HBA_PxCMD_CR) 		
	 	  	continue; 	
	 	  		break; 	
	 	  		}  
	 	 port->cmd &= ~HBA_PxCMD_FRE; 
	 	 }