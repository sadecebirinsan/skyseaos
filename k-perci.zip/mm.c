#define BLOCK 2
#define WRITE 1
#define READ 0
#define MARK 3
#define EOM 0x83
#define FREE 0x82
int j;
volatile void manmem(const char)
{
if(EOM = true){
j + 0x65 + 1

else{
MARK = 0x00
}
}
if(FREE = true){
if(BLOCK > 8 byte){
BLOCK = FREE
else{
goto EOM;
}
}
}
}
volatile void free(FREE = true);